import re
import os

input_data = open('gen/Gen.csv', 'r', encoding="utf-8")

num = 0
for row in input_data:
    if not re.match('#', row):
        if re.match('JaName', row):
            if num % 1 == 0:
                texts_path = "gen/"
                split_row = row.rstrip('\n').split(' = ')
                JaName = split_row[1]
                
                #---#
        if re.match('BigName', row):
            if num % 1 == 0:
                texts_path = "gen/"
                split_row = row.rstrip('\n').split(' = ')
                BigName = split_row[1]
                
                #---#
        if re.match('Name', row):
            if num % 1 == 0:
                texts_path = "gen/"
                split_row = row.rstrip('\n').split(' = ')
                ans = split_row[1]
                f = open(texts_path + "getitem.mcfunction", 'w', encoding="utf-8")
                f.write('''#''' + JaName + '''
execute store result score $''' + BigName + '''Slot1 Temporary run data remove storage menu:cook Data.CookItemStates[0].''' + ans + '''
scoreboard players operation $''' + BigName + '''CountSlot1 Temporary = $CookItemSlotCount1 Temporary
execute store result score $''' + BigName + '''Slot2 Temporary run data remove storage menu:cook Data.CookItemStates[1].''' + ans + '''
scoreboard players operation $''' + BigName + '''CountSlot2 Temporary = $CookItemSlotCount2 Temporary
execute store result score $''' + BigName + '''Slot3 Temporary run data remove storage menu:cook Data.CookItemStates[2].''' + ans + '''
scoreboard players operation $''' + BigName + '''CountSlot3 Temporary = $CookItemSlotCount3 Temporary
execute store result score $''' + BigName + '''Slot4 Temporary run data remove storage menu:cook Data.CookItemStates[3].''' + ans + '''
scoreboard players operation $''' + BigName + '''CountSlot4 Temporary = $CookItemSlotCount4 Temporary''')
                f.close()
                
                #---#
input_data.close()